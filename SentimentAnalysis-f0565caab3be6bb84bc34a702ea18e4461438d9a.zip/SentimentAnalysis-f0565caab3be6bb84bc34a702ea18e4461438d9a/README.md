# SentimentAnalysis
This project is to perform sentiment analysis on the web based Airline Feedback Management system. This uses a Natural Language Processing (NLP) pipeline with sentiment analysis to classify feedback as positive, negative, or neutral.
